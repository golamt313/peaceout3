package com.services.api.v1.models;

public class AuthRequest {
}
